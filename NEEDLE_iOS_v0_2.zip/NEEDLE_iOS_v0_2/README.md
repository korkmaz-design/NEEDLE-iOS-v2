# NEEDLE iOS — Native starter v0.2

Apple Music-first SwiftUI app with a Needle-inspired visualizer and a real ActivityKit Live Activity scaffold.

## What is implemented
- SwiftUI dark red/black constellation visualizer.
- Apple Music authorization, catalog search, and playback through MusicKit.
- Live Activity start/update/end calls connected to playback and pause/resume.
- Lock Screen and Dynamic Island presentation.
- Manual lyric preview text to demonstrate the visual treatment.

## What is not implemented yet
- Word-by-word synchronized lyrics. MusicKit's `Song.hasLyrics` is only a Boolean; it does not expose synchronized lyric text/timestamps. A properly licensed lyrics API/provider or user-supplied timed lyrics is required.
- Full-screen animated Lock Screen replacement. iOS does not permit third-party apps to replace the Lock Screen; Live Activities are system-controlled and compact.
- A signed IPA. This project must be built and signed in Xcode on macOS.

## Xcode setup
1. Create a new iOS App project named `NEEDLE`, SwiftUI, Swift, iOS 17+.
2. Add all files under `NEEDLE/` to the app target.
3. Add a Widget Extension named `NEEDLEWidget`, enable Live Activities.
4. Add `NEEDLEWidget/NEEDLEActivity.swift` and `NEEDLEWidget/NEEDLEWidgetBundle.swift` to the widget extension target.
5. Add `Shared/NEEDLEAttributes.swift` to BOTH app and widget extension targets.
6. Add `NSAppleMusicUsageDescription` = `NEEDLE uses Apple Music to play your selected music and show now-playing information.`
7. Add `NSSupportsLiveActivities` = `YES` to the app Info settings.
8. Configure signing with your Apple Developer Team. Enable MusicKit capability if offered by Xcode.
9. Build and run on a physical iPhone.

## iPhone-only workflow
You can download and review this source archive on iPhone, but iPhone itself cannot compile/sign a native Swift app. A cloud macOS build service or access to a Mac/Xcode is required. For App Store/TestFlight distribution, Apple signing and developer account setup are also required.
